# KMeans

Actual data set used is "ColorHistogram" from UCI
